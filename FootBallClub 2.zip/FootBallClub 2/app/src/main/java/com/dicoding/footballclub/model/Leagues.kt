package com.dicoding.footballclub.model

data class Leagues(val leagues : List<League>) {
}