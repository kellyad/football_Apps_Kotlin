package com.dicoding.footballclub.util

enum class Types {
    UPCOMING_MATCH, LAST_MATCH, FAVORITES, LEAGUE
}