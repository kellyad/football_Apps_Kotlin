package com.dicoding.footballclub.model

data class TeamResponse(
        val teams: List<Team>)